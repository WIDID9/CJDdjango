from django.apps import AppConfig


class InterflowConfig(AppConfig):
    name = 'interflow'
